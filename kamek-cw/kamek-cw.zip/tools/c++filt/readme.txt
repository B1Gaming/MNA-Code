powerpc-eabi-c++filt builds extracted from devkitPPC r33.1
https://wii.leseratte10.de/devkitPro/devkitPPC/r33%20(2018)/

More recent builds will not work because support for GNU-v2-ABI mangled names was removed from c++filt as a whole in January 2019:
https://sourceware.org/git/gitweb.cgi?p=binutils-gdb.git;a=commit;h=236f4ebe3ac7e8f94184fdcc39c70d74cc62b82a
https://github.com/bminor/binutils-gdb/commit/236f4ebe3ac7e8f94184fdcc39c70d74cc62b82a
